export interface PostsPanelOptions {

}
