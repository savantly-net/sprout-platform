# Widget Panel -  Native Plugin

The Widget Panel is **included** with Sprout.  

This panel renders 'widget' data provided by the server.  
The widget data is typically registered in code in the server app.  

It may be Markup, Markdown, or Json data. 

