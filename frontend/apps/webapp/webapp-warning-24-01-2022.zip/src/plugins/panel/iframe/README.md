# IFrame Panel -  Native Plugin

The IFrame Panel is **included** with Sprout.
