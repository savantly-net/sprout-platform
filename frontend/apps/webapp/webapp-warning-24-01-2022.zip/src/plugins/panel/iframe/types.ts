export interface IFrameOptions {
  url: string;
}
