# Table Panel -  Native Plugin

The Table Panel is **included** with Sprout.  

Use it to request content from a URL that may require query parameters.  

