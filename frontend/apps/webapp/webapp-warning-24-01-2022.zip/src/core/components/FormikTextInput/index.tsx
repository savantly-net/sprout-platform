import { FieldProps } from 'formik';
/* eslint-disable */
import React from 'react';
/* eslint-enable */
import { FormControl, FormLabel, Input } from '@chakra-ui/react';

import './styles.scss';

const FormikTextInput: React.FC<FieldProps> = ({ field, form }) => (
  <FormControl>
    <FormLabel className="FormikTextInput__label">{field.name}</FormLabel>
    <Input
      placeholder="Issue Description"
      onChange={(e: any) => form.setFieldValue(field.name, e.target.value)}
      onBlur={field.onBlur}
      name={field.name}
      value={field.value}
    />
  </FormControl>
);

export default FormikTextInput;
