/* eslint-disable */
import React, { Component } from 'react'
/* eslint-enable */

export class Spinner extends Component {
  render() {
    return (
      <div>
        <div className="spinner-wrapper">
          <div className="donut"></div>
        </div>
      </div>
    )
  }
}

export default Spinner
