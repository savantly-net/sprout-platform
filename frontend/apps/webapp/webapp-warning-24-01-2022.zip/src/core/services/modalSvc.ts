export class modalService {
  modalScope: any;
  reactModalRoot = document.body;
  reactModalNode = document.createElement('div');

  init() {}
}

export default modalService;
