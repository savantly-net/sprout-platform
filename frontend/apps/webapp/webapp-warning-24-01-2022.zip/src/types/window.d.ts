interface Window {
    System: System
}