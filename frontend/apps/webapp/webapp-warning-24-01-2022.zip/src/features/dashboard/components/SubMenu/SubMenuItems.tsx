import React, { FunctionComponent } from 'react';

interface Props {
}

export const SubMenuItems: FunctionComponent<Props> = () => {
  return (
    <>
      <div></div>
    </>
  );
};
